const express    = require('express');
const fs         = require('fs');
const path       = require('path');
const crypto     = require('crypto');
const nodemailer = require('nodemailer');

const app  = express();
const PORT = process.env.PORT || 3000;
const DB   = path.join(__dirname, 'database.json');

// ── Email Transporter ────────────────────────────────────────
let mailer = null;
if (process.env.EMAIL_HOST && process.env.EMAIL_USER && process.env.EMAIL_PASS) {
  mailer = nodemailer.createTransport({
    host:   process.env.EMAIL_HOST,
    port:   parseInt(process.env.EMAIL_PORT || '587'),
    secure: process.env.EMAIL_SECURE === 'true',
    auth:   { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS }
  });
  mailer.verify(err => {
    if (err) console.error('⚠️  Email transporter error:', err.message);
    else     console.log('📧 Email transporter ready →', process.env.EMAIL_USER);
  });
} else {
  console.log('ℹ️  No EMAIL_* env vars set — email notifications disabled. See .env.example.');
}

const EMAIL_FROM = process.env.EMAIL_FROM || '"Red Eye Café" <no-reply@redeyecafe.com>';

async function sendEmail(to, subject, html) {
  if (!mailer) { console.log(`[email skipped] To: ${to} | Subject: ${subject}`); return; }
  try {
    await mailer.sendMail({ from: EMAIL_FROM, to, subject, html });
    console.log(`📧 Email sent → ${to}`);
  } catch (err) {
    console.error(`⚠️  Email failed (${to}):`, err.message);
  }
}

// ── Email Templates ──────────────────────────────────────────
function bookingConfirmationHtml(b) {
  const bid = String(b.id).slice(-6).toUpperCase();
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Booking Confirmed — Red Eye Café</title>
<style>
  body{margin:0;padding:0;background:#1a1a1a;font-family:'Helvetica Neue',Arial,sans-serif;color:#d4c5a9;}
  .wrap{max-width:520px;margin:32px auto;background:#0f0f0f;border:1px solid rgba(255,107,53,0.2);border-radius:6px;overflow:hidden;}
  .hdr{background:linear-gradient(135deg,#1a0a00 0%,#2d1200 100%);padding:28px 32px;text-align:center;border-bottom:2px solid #ff6b35;}
  .logo{font-size:1.5rem;font-weight:800;color:#ff6b35;letter-spacing:0.15em;}
  .logo span{color:#d4c5a9;}
  .badge{display:inline-block;margin-top:10px;padding:4px 16px;background:rgba(39,174,96,0.15);border:1px solid #27ae60;border-radius:20px;color:#27ae60;font-size:0.78rem;font-weight:700;letter-spacing:0.08em;}
  .body{padding:28px 32px;}
  h2{margin:0 0 6px;color:#ff6b35;font-size:1.1rem;font-weight:700;}
  .ref{font-family:monospace;font-size:0.72rem;color:#888;margin-bottom:20px;}
  .card{background:rgba(255,107,53,0.05);border:1px solid rgba(255,107,53,0.15);border-radius:4px;padding:16px 20px;margin:16px 0;}
  .row{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.05);font-size:0.85rem;}
  .row:last-child{border-bottom:none;}
  .lbl{color:#888;}
  .val{color:#d4c5a9;font-weight:600;text-align:right;}
  .policy{margin-top:20px;padding:12px 16px;background:rgba(231,76,60,0.06);border-left:3px solid #e74c3c;border-radius:0 4px 4px 0;font-size:0.78rem;color:#c0392b;}
  .ftr{padding:20px 32px;border-top:1px solid rgba(255,255,255,0.06);text-align:center;font-size:0.75rem;color:#555;}
  .ftr a{color:#ff6b35;text-decoration:none;}
</style></head>
<body>
  <div class="wrap">
    <div class="hdr">
      <div class="logo">👁 <span>Red</span> Eye Café</div>
      <div class="badge">✓ BOOKING CONFIRMED</div>
    </div>
    <div class="body">
      <h2>Hi ${b.user_name || 'there'},</h2>
      <p style="margin:4px 0 0;font-size:0.88rem;color:#999;">Your seat reservation has been confirmed. We look forward to seeing you!</p>
      <div class="ref">Booking Reference: #${bid}</div>
      <div class="card">
        <div class="row"><span class="lbl">Date</span><span class="val">${b.date}</span></div>
        <div class="row"><span class="lbl">Time Slot</span><span class="val">${b.time_slot}</span></div>
        <div class="row"><span class="lbl">Guests</span><span class="val">${b.guests} person${b.guests > 1 ? 's' : ''}</span></div>
        ${b.special_requests ? `<div class="row"><span class="lbl">Special Requests</span><span class="val">${b.special_requests}</span></div>` : ''}
        <div class="row"><span class="lbl">Booked At</span><span class="val">${new Date(b.booked_at).toLocaleString('en-IN', { day:'numeric', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' })}</span></div>
      </div>
      <div class="policy">
        <strong>Cancellation Policy:</strong> Cancellations made within 24 hours of your booking time will incur a fee of <strong>₹100 per seat</strong> (₹${b.guests * 100} for your reservation).
      </div>
    </div>
    <div class="ftr">
      <strong style="color:#d4c5a9;">Red Eye Café</strong><br>
      Rajarampuri, 1st Lane, Near Pantaloons, Kolhapur<br>
      +91 98765 43210 &nbsp;·&nbsp; Hours: 9:00 AM – 10:00 PM<br><br>
      <span style="color:#444;">This is an automated confirmation. Please do not reply to this email.</span>
    </div>
  </div>
</body></html>`;
}

function bookingCancellationHtml(b) {
  const bid     = String(b.id).slice(-6).toUpperCase();
  const hasCharge = b.cancellation_charge > 0;
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Booking Cancelled — Red Eye Café</title>
<style>
  body{margin:0;padding:0;background:#1a1a1a;font-family:'Helvetica Neue',Arial,sans-serif;color:#d4c5a9;}
  .wrap{max-width:520px;margin:32px auto;background:#0f0f0f;border:1px solid rgba(231,76,60,0.2);border-radius:6px;overflow:hidden;}
  .hdr{background:linear-gradient(135deg,#1a0000 0%,#2d0a0a 100%);padding:28px 32px;text-align:center;border-bottom:2px solid #e74c3c;}
  .logo{font-size:1.5rem;font-weight:800;color:#e74c3c;letter-spacing:0.15em;}
  .logo span{color:#d4c5a9;}
  .badge{display:inline-block;margin-top:10px;padding:4px 16px;background:rgba(231,76,60,0.12);border:1px solid #e74c3c;border-radius:20px;color:#e74c3c;font-size:0.78rem;font-weight:700;letter-spacing:0.08em;}
  .body{padding:28px 32px;}
  h2{margin:0 0 6px;color:#e74c3c;font-size:1.1rem;font-weight:700;}
  .ref{font-family:monospace;font-size:0.72rem;color:#888;margin-bottom:20px;}
  .card{background:rgba(231,76,60,0.05);border:1px solid rgba(231,76,60,0.15);border-radius:4px;padding:16px 20px;margin:16px 0;}
  .row{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.05);font-size:0.85rem;}
  .row:last-child{border-bottom:none;}
  .lbl{color:#888;}
  .val{color:#d4c5a9;font-weight:600;text-align:right;}
  .charge-box{margin-top:16px;padding:14px 18px;background:rgba(231,76,60,0.08);border:1px solid rgba(231,76,60,0.3);border-radius:4px;text-align:center;}
  .free-box{margin-top:16px;padding:14px 18px;background:rgba(39,174,96,0.07);border:1px solid rgba(39,174,96,0.25);border-radius:4px;text-align:center;color:#27ae60;font-size:0.85rem;}
  .ftr{padding:20px 32px;border-top:1px solid rgba(255,255,255,0.06);text-align:center;font-size:0.75rem;color:#555;}
</style></head>
<body>
  <div class="wrap">
    <div class="hdr">
      <div class="logo">👁 <span>Red</span> Eye Café</div>
      <div class="badge">✗ BOOKING CANCELLED</div>
    </div>
    <div class="body">
      <h2>Hi ${b.user_name || 'there'},</h2>
      <p style="margin:4px 0 0;font-size:0.88rem;color:#999;">Your seat reservation has been cancelled.</p>
      <div class="ref">Booking Reference: #${bid}</div>
      <div class="card">
        <div class="row"><span class="lbl">Date</span><span class="val">${b.date}</span></div>
        <div class="row"><span class="lbl">Time Slot</span><span class="val">${b.time_slot}</span></div>
        <div class="row"><span class="lbl">Guests</span><span class="val">${b.guests} person${b.guests > 1 ? 's' : ''}</span></div>
        <div class="row"><span class="lbl">Cancelled At</span><span class="val">${new Date(b.cancelled_at).toLocaleString('en-IN', { day:'numeric', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' })}</span></div>
      </div>
      ${hasCharge
        ? `<div class="charge-box">
            <div style="font-size:0.78rem;color:#999;margin-bottom:4px;">CANCELLATION FEE APPLIED</div>
            <div style="font-size:1.6rem;font-weight:800;color:#e74c3c;">₹${b.cancellation_charge}</div>
            <div style="font-size:0.76rem;color:#c0392b;margin-top:4px;">${b.cancellation_reason}</div>
           </div>`
        : `<div class="free-box">✓ No cancellation fee — cancelled with sufficient notice.</div>`}
    </div>
    <div class="ftr">
      <strong style="color:#d4c5a9;">Red Eye Café</strong><br>
      Rajarampuri, 1st Lane, Near Pantaloons, Kolhapur<br>
      +91 98765 43210 &nbsp;·&nbsp; Hours: 9:00 AM – 10:00 PM<br><br>
      <span style="color:#444;">This is an automated notification. Please do not reply to this email.</span>
    </div>
  </div>
</body></html>`;
}

// ── Single Admin Session ─────────────────────────────────────
let activeAdminToken = null;
let activeAdminEmail = null;

// ── Middleware ──────────────────────────────────────────────
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── JSON Database Helpers ───────────────────────────────────
function readDB() {
  if (!fs.existsSync(DB)) {
    const empty = { users: [], orders: [], contacts: [], bookings: [], reviews: [] };
    fs.writeFileSync(DB, JSON.stringify(empty, null, 2));
    return empty;
  }
  const data = JSON.parse(fs.readFileSync(DB, 'utf8'));
  if (!data.bookings) data.bookings = [];
  if (!data.reviews)  data.reviews  = [];
  return data;
}

function writeDB(data) {
  fs.writeFileSync(DB, JSON.stringify(data, null, 2));
}

// ── Seed default admin if not present ──────────────────────
function seedAdmin() {
  const db = readDB();
  if (!db.admins) db.admins = [];
  const exists = db.admins.find(a => a.email === 'admin@redeyecafe.com');
  if (!exists) {
    db.admins.push({ id: 1, name: 'Admin', email: 'admin@redeyecafe.com', password: 'admin123' });
    writeDB(db);
    console.log('👑 Default admin created → admin@redeyecafe.com / admin123');
  }
}
seedAdmin();
console.log('✅ JSON database ready (database.json)');

// ── REGISTER ────────────────────────────────────────────────
app.post('/api/register', (req, res) => {
  const { name, email, phone, password } = req.body;
  if (!name || !email || !password)
    return res.json({ success: false, message: 'Please fill all required fields.' });
  if (password.length < 6)
    return res.json({ success: false, message: 'Password must be at least 6 characters.' });

  const db = readDB();
  if (db.users.find(u => u.email === email))
    return res.json({ success: false, message: 'Email already registered.' });

  const user = { id: Date.now(), name, email, phone: phone || '', password, joined: new Date().toISOString() };
  db.users.push(user);
  writeDB(db);

  const { password: _, ...safeUser } = user;
  res.json({ success: true, user: safeUser, message: 'Account created!' });
});

// ── LOGIN ───────────────────────────────────────────────────
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.json({ success: false, message: 'Please fill all fields.' });

  const db   = readDB();
  const user = db.users.find(u => u.email === email && u.password === password);
  if (!user)
    return res.json({ success: false, message: 'Invalid email or password.' });

  const { password: _, ...safeUser } = user;
  res.json({ success: true, user: safeUser, message: 'Login successful!' });
});

// ── ADMIN LOGIN (Single Session) ─────────────────────────────
app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.json({ success: false, message: 'Please fill all fields.' });

  const db    = readDB();
  const admins = db.admins || [];
  const admin  = admins.find(a => a.email === email && a.password === password);
  if (!admin)
    return res.json({ success: false, message: 'Invalid admin email or password.' });

  // Single session check
  if (activeAdminToken && activeAdminEmail !== email) {
    return res.json({ success: false, message: 'Admin dashboard is already open in another session. Please close the other session first.' });
  }

  // Issue new token
  activeAdminToken = crypto.randomBytes(32).toString('hex');
  activeAdminEmail = email;

  const { password: _, ...safeAdmin } = admin;
  res.json({ success: true, user: safeAdmin, token: activeAdminToken, message: 'Admin login successful!' });
});

// ── ADMIN LOGOUT ─────────────────────────────────────────────
app.post('/api/admin/logout', (req, res) => {
  const { token } = req.body;
  if (token && token === activeAdminToken) {
    activeAdminToken = null;
    activeAdminEmail = null;
  }
  res.json({ success: true, message: 'Logged out.' });
});

// ── ADMIN SESSION CHECK ──────────────────────────────────────
app.get('/api/admin/session', (req, res) => {
  const token = req.headers['x-admin-token'];
  if (!token || token !== activeAdminToken)
    return res.json({ valid: false });
  res.json({ valid: true });
});

// ── PLACE ORDER ─────────────────────────────────────────────
app.post('/api/orders', (req, res) => {
  const { user_email, items, total, delivery_address, order_type } = req.body;
  if (!user_email || !items || !total)
    return res.json({ success: false, message: 'Invalid order data.' });

  const db = readDB();
  db.orders.push({
    id: Date.now(),
    user_email,
    items,
    total,
    delivery_address: delivery_address || 'Not provided',
    order_type: order_type || 'delivery',
    payment_method: 'Cash on Delivery',
    status: 'Pending',
    ordered_at: new Date().toISOString()
  });
  writeDB(db);
  res.json({ success: true, message: 'Order placed successfully!' });
});

// ── GET ORDERS (per user) ───────────────────────────────────
app.get('/api/orders/:email', (req, res) => {
  const db     = readDB();
  const orders = db.orders.filter(o => o.user_email === req.params.email).reverse();
  res.json({ success: true, orders });
});

// ── ADMIN: ALL ORDERS ───────────────────────────────────────
app.get('/api/admin/orders', (req, res) => {
  const db = readDB();
  res.json({ success: true, orders: db.orders });
});

// ── ADMIN: UPDATE ORDER STATUS ──────────────────────────────
app.patch('/api/admin/orders/:id', (req, res) => {
  const { status } = req.body;
  const db = readDB();
  const order = db.orders.find(o => String(o.id) === req.params.id);
  if (!order) return res.json({ success: false, message: 'Order not found.' });
  order.status = status;
  writeDB(db);
  res.json({ success: true, order });
});

// ── ADMIN: ALL USERS ────────────────────────────────────────
app.get('/api/admin/users', (req, res) => {
  const db = readDB();
  const safeUsers = db.users.map(({ password, ...u }) => u);
  res.json({ success: true, users: safeUsers });
});

// ── ADMIN: ALL CONTACTS ─────────────────────────────────────
app.get('/api/admin/contacts', (req, res) => {
  const db = readDB();
  res.json({ success: true, contacts: db.contacts });
});

// ── CONTACT ─────────────────────────────────────────────────
app.post('/api/contact', (req, res) => {
  const { name, email, subject, message } = req.body;
  if (!name || !email)
    return res.json({ success: false, message: 'Name and email are required.' });

  const db = readDB();
  db.contacts.push({ id: Date.now(), name, email, subject, message, sent_at: new Date().toISOString() });
  writeDB(db);
  res.json({ success: true, message: 'Message sent successfully!' });
});

// ── REVIEWS ─────────────────────────────────────────────────
app.post('/api/reviews', (req, res) => {
  const { user_email, user_name, stars, text } = req.body;
  if (!user_email || !stars || !text)
    return res.json({ success: false, message: 'Missing required fields.' });
  if (stars < 1 || stars > 5)
    return res.json({ success: false, message: 'Stars must be 1-5.' });

  const db = readDB();
  if (!db.reviews) db.reviews = [];
  db.reviews.unshift({
    id: Date.now(),
    user_email, user_name,
    stars: parseInt(stars),
    text,
    verified: true,
    date: new Date().toISOString()
  });
  writeDB(db);
  res.json({ success: true, message: 'Review posted!' });
});

app.get('/api/reviews', (req, res) => {
  const db = readDB();
  res.json({ success: true, reviews: (db.reviews || []) });
});

// ── SEAT BOOKINGS ────────────────────────────────────────────
const CANCELLATION_CHARGE_PER_SEAT = 100; // ₹100 per seat cancellation fee

app.post('/api/bookings', (req, res) => {
  const { user_email, user_name, user_phone, date, time_slot, guests, special_requests } = req.body;
  if (!user_email || !date || !time_slot || !guests)
    return res.json({ success: false, message: 'Missing required booking fields.' });

  const db = readDB();
  if (!db.bookings) db.bookings = [];

  const booking = {
    id: Date.now(),
    user_email,
    user_name: user_name || 'Guest',
    user_phone: user_phone || '',
    date,
    time_slot,
    guests: parseInt(guests),
    special_requests: special_requests || '',
    status: 'Confirmed',
    cancellation_charge: 0,
    booked_at: new Date().toISOString()
  };

  db.bookings.push(booking);
  writeDB(db);
  res.json({ success: true, booking, message: 'Seat booking confirmed!' });

  // Fire confirmation email (non-blocking)
  sendEmail(
    booking.user_email,
    '✅ Booking Confirmed — Red Eye Café',
    bookingConfirmationHtml(booking)
  );
});

app.get('/api/bookings/:email', (req, res) => {
  const db = readDB();
  const bookings = (db.bookings || []).filter(b => b.user_email === req.params.email).reverse();
  res.json({ success: true, bookings });
});

// Cancel booking with charges
app.patch('/api/bookings/:id/cancel', (req, res) => {
  const db = readDB();
  const booking = (db.bookings || []).find(b => String(b.id) === req.params.id);
  if (!booking) return res.json({ success: false, message: 'Booking not found.' });
  if (booking.status === 'Cancelled') return res.json({ success: false, message: 'Already cancelled.' });

  // Determine cancellation charge
  const bookingDateTime = new Date(booking.date + 'T' + booking.time_slot.split(' - ')[0]);
  const now = new Date();
  const hoursUntilBooking = (bookingDateTime - now) / (1000 * 60 * 60);

  let charge = 0;
  let reason = 'No charge applied (cancelled with sufficient notice).';

  if (hoursUntilBooking < 24) {
    charge = booking.guests * CANCELLATION_CHARGE_PER_SEAT;
    reason = `Cancellation within 24 hours: ₹${CANCELLATION_CHARGE_PER_SEAT} × ${booking.guests} seat(s) = ₹${charge}`;
  }

  booking.status = 'Cancelled';
  booking.cancellation_charge = charge;
  booking.cancellation_reason = reason;
  booking.cancelled_at = new Date().toISOString();

  writeDB(db);
  res.json({ success: true, booking, charge, reason, message: charge > 0 ? `Booking cancelled. Cancellation fee of ₹${charge} applies.` : 'Booking cancelled with no charge.' });

  // Fire cancellation email (non-blocking)
  sendEmail(
    booking.user_email,
    charge > 0
      ? `❌ Booking Cancelled (Fee: ₹${charge}) — Red Eye Café`
      : '❌ Booking Cancelled — Red Eye Café',
    bookingCancellationHtml(booking)
  );
});

// Admin: all bookings
app.get('/api/admin/bookings', (req, res) => {
  const db = readDB();
  res.json({ success: true, bookings: (db.bookings || []).reverse() });
});

// Admin: update booking status
app.patch('/api/admin/bookings/:id', (req, res) => {
  const { status } = req.body;
  const db = readDB();
  const booking = (db.bookings || []).find(b => String(b.id) === req.params.id);
  if (!booking) return res.json({ success: false, message: 'Booking not found.' });
  booking.status = status;
  writeDB(db);
  res.json({ success: true, booking });
});

// ── Catch-all → index.html ───────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── Start ────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`☕ Red Eye Café running → http://localhost:${PORT}`);
  console.log(`📍 Address: Rajarampuri, 1st Lane, near Pantaloons`);
  console.log(`🕐 Hours: 9:00 AM – 10:00 PM`);
  console.log(`📁 Database file: database.json`);
});
