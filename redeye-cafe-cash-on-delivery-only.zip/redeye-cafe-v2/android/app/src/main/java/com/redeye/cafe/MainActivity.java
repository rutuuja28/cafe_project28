package com.redeye.cafe;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
