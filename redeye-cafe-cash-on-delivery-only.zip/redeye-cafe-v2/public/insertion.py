class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

def traverse_with_position(head):
    temp = head
    pos = 1
    if not head:
        print("List is empty")
        return
    while temp:
        print(f"{pos}:{temp.data}", end=" -> ")
        temp = temp.next
        pos += 1
    print("None")

def insert_at_beginning(head, data):
    new_node = Node(data)
    new_node.next = head
    return new_node

def insert_end(head, data):
    new_node = Node(data)
    if head is None:
        return new_node
    temp = head
    while temp.next:
        temp = temp.next
    temp.next = new_node
    return head
    
def insert_pos(head, pos, data):
    if pos <= 0:
        print("Invalid position")
        return head
    new_node = Node(data)
    if pos == 1:
        new_node.next = head
        return new_node
    temp = head
    for i in range(pos-2):
        if temp is None:
            print("Position out of range")
            return head
        temp = temp.next
    new_node.next = temp.next
    temp.next = new_node
    return head

# ====== Driver Code ======
# Create initial list: 10 -> 20 -> 30
head = Node(10)
head.next = Node(20)
head.next = Node(30)

print("Original list:")
traverse_with_position(head)

# Insert at end
head = insert_end(head, 40)
print("\nAfter inserting 40 at end:")
traverse_with_position(head)

# Insert at random position 2
head = insert_pos(head, 2, 15)
print("\nAfter inserting 15 at position 2:")
traverse_with_position(head)

# Insert at beginning
head = insert_at_beginning(head, 5)
print("\nAfter inserting 5 at beginning:")
traverse_with_position(head)