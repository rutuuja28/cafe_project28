class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

def traverse_with_position(head):
    temp = head
    pos = 1
    while temp is not None:
        print(f"Position {pos}: {temp.data}", end=" -> ")
        temp = temp.next
        pos += 1
    print("None")

def insert_at_beginning(head, data):
    new_node = Node(data)
    new_node.next = head
    head = new_node
    return head

def insert_end(head, data):
    if head is None:  
        return Node(data)
    temp = head
    while temp.next:
        temp = temp.next
    temp.next = Node(data)
    return head
    
def insert_pos(head, pos, data):
    if pos == 1:
        return insert_at_beginning(head, data)
    temp = head
    for i in range(pos-2): 
        temp = temp.next
    new = Node(data)
    new.next, temp.next = temp.next, new
    return head


n1 = Node(10)
n2 = Node(20)
n3 = Node(30)

n1.next = n2
n2.next = n3

head = n1


traverse_with_position(head)