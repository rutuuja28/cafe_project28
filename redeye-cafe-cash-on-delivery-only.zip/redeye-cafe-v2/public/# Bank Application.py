# Bank Application

balance = float(input("Enter Initial Balance: "))

while True:
    print("\n----- BANK MENU -----")
    print("1. Check Balance")
    print("2. Deposit")
    print("3. Withdraw")
    print("4. Print Balance")
    print("5. Exit")

    choice = int(input("Enter your choice: "))

    if choice == 1:
        print("Current Balance =", balance)

    elif choice == 2:
        amount = float(input("Enter Deposit Amount: "))
        balance = balance + amount
        print("Amount Deposited Successfully.")
        print("Updated Balance =", balance)

    elif choice == 3:
        amount = float(input("Enter Withdrawal Amount: "))
        if amount > balance:
            print("Insufficient Balance")
        else:
            balance = balance - amount
            print("Withdrawal Successful")
            print("Remaining Balance =", balance)

    elif choice == 4:
        print("Available Balance =", balance)

    elif choice == 5:
        print("Thank You! Exiting...")
        break

    else:
        print("Invalid Choice")