def postfix(exp):
    stack = []

    for x in exp.split():
        if x.isdigit():
            stack.append(int(x))
        else:
            b = stack.pop()
            a = stack.pop()

            if x == '+': stack.append(a + b)
            elif x == '-': stack.append(a - b)
            elif x == '*': stack.append(a * b)
            elif x == '/': stack.append(a / b)

    return stack[-1]

print(postfix("9 2 3 * +"))


def prefix(exp):
    stack = []

    for x in exp.split()[::-1]:
        if x.isdigit():
            stack.append(int(x))
        else:
            b = stack.pop()
            a = stack.pop()

            if x == '+':
                stack.append(a + b)
            elif x == '-':
                stack.append(a - b)
            elif x == '*':
                stack.append(a * b)
            elif x == '/':
                stack.append(a / b)

    return stack[-1]

print(prefix("+ 9 * 6 8"))


queue=[]

queue.append[10]
queue.append[20]
queue.append[30]

print(queue.pop(0))

print("queue after dequeue",queue)
print("Front element",queue[0])
print("Rear element",queue[-1])
print("size",len(queue))

if len(queue)==0:
    print("queue is empty")
else:
    print("queue is not empty")

  z   















 
