arr = [5,4,-1,7,8]

max_sum= arr[0]

for i in range (len(arr)):
    for j in range(i,len(arr)):

        current_sum= 0

        for k in range(i,j+1):
            current_sum+= arr[k]

            if current_sum>max_sum:
                max_sum = current_sum
print("maximum sum=",max_sum)



arr=[5,4,-2,7,8] 

max_sum= arr[0]

for i in range(len(arr)):
    current_sum=0

    for j in range(len(arr)):
        current_sum+= arr[j]
   
        if current_sum>max_sum:
            max_sum = current_sum

print("maximum sum=",max_sum)



      


class solution(object):
   def maxsubArray(self,nums):
       current_sum=nums[0]
       max_sum=nums[0]

       for i in range(1,len(nums)):
           
           current_sum=max(nums[i],current_sum+nums[i])
           if current_sum>max_sum:
               max_sum = current_sum
               return max_sum


student = {"name":"rutuja","age":"20","course":"Btech"}

print("original dictionary:",student)

student["grade"]="A"
student["age"]=20
print("After insertion/update:",student)

del student["course"]
student.pop("age")
print("After deletion/update:",student)






def insertionSort(arr):
  
    for i in range(1, len(arr)):
        key = arr[i] 
        j = i - 1

        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1

        arr[j + 1] = key

nums = list(map(int, input("enter numbers separated by space: ").split()))
print("Before:", nums)
insertionSort(nums)
print("After:", nums)

def bubbleSort(arr):
    n = len(arr)
    for i in range(n):
        swapped = False
       
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
       
        if not swapped:
            break

nums = list(map(int, input("Bubble Sort - enter numbers: ").split()))
bubbleSort(nums)
print("After:", nums)


def selectionSort(arr):
    n = len(arr)
    for i in range(n):
        min_idx = i
      
        for j in range(i + 1, n):
            if arr[j] < arr[min_idx]:
                min_idx = j
        
        arr[i], arr[min_idx] = arr[min_idx], arr[i]

nums = list(map(int, input("Selection Sort - enter numbers: ").split()))
selectionSort(nums)
print("After:", nums)


def binarySearch(arr, target):
    low = 0
    high = len(arr) - 1

    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == target:
            return mid 
        elif arr[mid] < target:
            low = mid + 1 
        else:
            high = mid - 1 
    return -1 

nums = list(map(int, input("Binary Search - enter SORTED numbers: ").split()))
target = int(input("Enter target to search: "))
index = binarySearch(nums, target)

if index!= -1:
    print(f"Found {target} at index {index}")
else:
    print(f"{target} not found")

