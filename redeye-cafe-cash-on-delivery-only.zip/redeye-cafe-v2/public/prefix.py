stack=[]

exp="-*+2345"

for ch in reversed(exp):

    if ch.isdigit():
        stack.append(int(ch))

    else:

        a=stack.pop()
        b=stack.pop()

        if ch=='-':
            stack.append(a-b)
        elif ch=='+':
            stack.append(a+b)
        elif ch=='*':
            stack.append(a*b)
        elif ch=='/':
            stack.append(a/b)

                        
