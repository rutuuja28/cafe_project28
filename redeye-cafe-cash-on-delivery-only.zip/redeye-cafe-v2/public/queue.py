queue = [1, 2, 3, 5]

print("Queue:", queue)

print("Deleted:", queue.pop(0))

print("Queue after dequeue:", queue)
print("Front element:", queue[0])
print("Rear element:", queue[-1])
print("Size:", len(queue))

if len(queue) == 0:
    print("Queue is empty")
else:
    print("Queue is not empty")



queue = [10,20,30,40,50]

target= int (input("enter element to search:"))

found= False

for item in queue:
    if item == target:
        found= True
        break


if found:
    print("element found")

else:
    print("element not found")    



queue=[10,20,30,40,50]
queue=[]

while queue:
    stack.append(queue.pop(0))

while stack:
    queue.append(stack.pop(0))    

print("reversed queue:")
print(queue)    