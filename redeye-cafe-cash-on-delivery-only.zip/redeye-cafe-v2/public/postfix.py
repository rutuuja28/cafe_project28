
print(10 - 5 - 2)  



print(231 * + 9)