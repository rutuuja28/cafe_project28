queue=[10,20,30,40,50]
stack=[]

while queue:
    stack.append(queue.pop(0))

while stack:
    queue.append(stack.pop(0))    

print("reversed queue:")
print(queue)   

queue = [1, 2, 3, 2, 5, 1, 3]
new_queue = []

for x in queue:
    if x not in new_queue:
        new_queue.append(x)

print("Queue after removing duplicates:", new_queue)


queue1 = [1, 2, 3, 5]
queue2 = [1, 6, 3, 5]

if queue1 == queue2:
    print("Both queues are same")
else:
    print("Queues are not same")