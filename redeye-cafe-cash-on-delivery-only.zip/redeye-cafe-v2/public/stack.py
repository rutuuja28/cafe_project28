stack = []


stack.append(10)
stack.append(20)
stack.append(30)

print(stack)


print(stack.pop())  
print(stack)


class Stack:
    def __init__(self):
        self.items = []

    def push(self, value):
        self.items.append(value)

    def pop(self):
        return self.items.pop()


stack = Stack()

stack.push(10)
stack.push(20)
stack.push(30)

print(stack.pop())  

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


a = Node(10)
b = Node(20)
c = Node(30)

a.next = b
b.next = c

print(a.data)
print(a.next.data)
print(a.next.next.data)


list = [10, 20, 30]

for i in list:
    print(i)



class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


top = None


new = Node(10)
new.next = top
top = new

new = Node(20)
new.next = top
top = new

new = Node(30)
new.next = top
top = new

print(top.data)
top = top.next    


class stack:
    def __init__(self):
        self.head=None
        self.size=0

    def push (self,value):
        new_node= Node(value)

#reversel++  

stack=[]

string=input("enter string:")

for ch in string:
    stack.append(ch)

reverse=""

while stack:
        reverse +=stack.pop()

print(reverse)  


#decimal to binary

n = int(input("Enter decimal number: "))

binary = ""
if n == 0:
    binary = "0"

while n > 0:
    binary = str(n % 2) + binary  
    n = n // 2

print("Binary:", binary)


  